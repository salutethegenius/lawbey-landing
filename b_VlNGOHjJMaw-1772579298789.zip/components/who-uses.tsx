"use client"

import { useAnimateIn } from "@/hooks/use-animate-in"
import { User, Building, GraduationCap, Gavel } from "lucide-react"

const personas = [
  {
    icon: User,
    label: "Individuals",
    description: "Curious people who want to understand their rights under Bahamian law.",
  },
  {
    icon: Building,
    label: "Small Business Owners",
    description: "Entrepreneurs who need quick legal clarity before consulting a lawyer.",
  },
  {
    icon: Gavel,
    label: "Paralegals & Lawyers",
    description: "Legal professionals who want faster, citation-backed research.",
  },
  {
    icon: GraduationCap,
    label: "Students & Researchers",
    description: "Anyone learning or writing about Bahamian law and legal systems.",
  },
]

export function WhoUses() {
  const [headerRef, headerVisible] = useAnimateIn<HTMLDivElement>()

  return (
    <section id="who-uses" className="relative py-32 px-6 lg:px-8">
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-7xl">
        <div className="h-px bg-border" />
      </div>

      <div className="mx-auto max-w-7xl">
        <div
          ref={headerRef}
          className={`mb-20 text-center transition-all duration-1000 ${
            headerVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
          }`}
        >
          <p className="text-xs tracking-[0.2em] uppercase text-accent font-mono mb-4">
            For Everyone
          </p>
          <h2 className="text-3xl md:text-5xl font-bold tracking-tight text-balance">
            Who uses LawBey
          </h2>
          <p className="mt-4 text-muted-foreground text-lg max-w-xl mx-auto leading-relaxed">
            Start free, upgrade if you need professional features.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {personas.map((persona, i) => (
            <PersonaCard key={persona.label} persona={persona} index={i} />
          ))}
        </div>
      </div>
    </section>
  )
}

function PersonaCard({
  persona,
  index,
}: {
  persona: (typeof personas)[number]
  index: number
}) {
  const [ref, isVisible] = useAnimateIn<HTMLDivElement>()
  const Icon = persona.icon

  return (
    <div
      ref={ref}
      className={`group text-center p-8 rounded-lg border border-border bg-card/30 hover:bg-card/60 transition-all duration-500 ${
        isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"
      }`}
      style={{ transitionDelay: `${index * 120}ms` }}
    >
      <div className="mx-auto mb-5 h-12 w-12 rounded-full bg-secondary flex items-center justify-center transition-all duration-300 group-hover:bg-accent/10 group-hover:scale-110">
        <Icon className="h-5 w-5 text-muted-foreground transition-colors duration-300 group-hover:text-accent" />
      </div>
      <h3 className="font-semibold mb-2">{persona.label}</h3>
      <p className="text-sm text-muted-foreground leading-relaxed">
        {persona.description}
      </p>
    </div>
  )
}
