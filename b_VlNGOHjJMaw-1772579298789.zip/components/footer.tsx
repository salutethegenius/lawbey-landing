import Link from "next/link"

export function Footer() {
  return (
    <footer className="border-t border-border py-16 px-6 lg:px-8">
      <div className="mx-auto max-w-7xl">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-16">
          {/* Brand */}
          <div className="md:col-span-1">
            <Link href="/" className="flex items-center gap-2 mb-4">
              <div className="h-7 w-7 rounded-md bg-foreground flex items-center justify-center">
                <span className="text-background font-bold text-xs font-mono">LB</span>
              </div>
              <span className="text-foreground font-semibold tracking-tight">
                LawBey
              </span>
            </Link>
            <p className="text-sm text-muted-foreground leading-relaxed">
              AI-powered legal research
              <br />
              for The Bahamas.
            </p>
          </div>

          {/* Product */}
          <div>
            <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-4">
              Product
            </p>
            <div className="flex flex-col gap-3">
              <FooterLink href="#how-it-works">How It Works</FooterLink>
              <FooterLink href="#features">Features</FooterLink>
              <FooterLink href="#pro">LawBey Pro</FooterLink>
              <FooterLink href="https://beta.lawbey.com">Try Free</FooterLink>
            </div>
          </div>

          {/* Company */}
          <div>
            <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-4">
              Company
            </p>
            <div className="flex flex-col gap-3">
              <FooterLink href="#mission">Mission</FooterLink>
              <FooterLink href="mailto:hello@lawbey.com">Contact</FooterLink>
            </div>
          </div>

          {/* Legal */}
          <div>
            <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-4">
              Legal
            </p>
            <div className="flex flex-col gap-3">
              <FooterLink href="#">Privacy Policy</FooterLink>
              <FooterLink href="#">Terms of Service</FooterLink>
            </div>
          </div>
        </div>

        {/* Legal notice */}
        <div className="border-t border-border pt-8">
          <p className="text-xs text-muted-foreground leading-relaxed max-w-3xl">
            LawBey provides general information about Bahamian law for
            educational purposes only. This is not legal advice. For specific
            legal matters, always consult a qualified Bahamian attorney.
          </p>
          <p className="mt-4 text-xs text-muted-foreground/60">
            {'© 2026 LawBey LLC. All rights reserved.'}
          </p>
        </div>
      </div>
    </footer>
  )
}

function FooterLink({
  href,
  children,
}: {
  href: string
  children: React.ReactNode
}) {
  return (
    <Link
      href={href}
      className="text-sm text-muted-foreground hover:text-foreground transition-colors duration-300"
    >
      {children}
    </Link>
  )
}
