"use client"

import { useAnimateIn } from "@/hooks/use-animate-in"

export function Mission() {
  const [ref, isVisible] = useAnimateIn<HTMLDivElement>()

  return (
    <section className="relative py-32 px-6 lg:px-8">
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-7xl">
        <div className="h-px bg-border" />
      </div>

      <div className="mx-auto max-w-3xl text-center">
        <div
          ref={ref}
          className={`transition-all duration-1000 ${
            isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
          }`}
        >
          <p className="text-xs tracking-[0.2em] uppercase text-accent font-mono mb-4">
            Our Mission
          </p>
          <h2 className="text-3xl md:text-4xl font-bold tracking-tight mb-8 text-balance leading-tight">
            Put Bahamian law in the hands of every Bahamian
          </h2>
          <p className="text-muted-foreground text-lg leading-relaxed text-pretty">
            The law shapes daily life, but most people never see the actual rules
            that affect them. LawBey exists so people make choices with clarity,
            not confusion. Built locally, grown with the country.
          </p>
        </div>
      </div>
    </section>
  )
}
