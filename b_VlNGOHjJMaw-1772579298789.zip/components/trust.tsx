"use client"

import { useAnimateIn } from "@/hooks/use-animate-in"
import { CheckCircle2, AlertTriangle } from "lucide-react"

const trustPoints = [
  "Retrieval first, then AI explains the retrieved material",
  "Answers are traceable, citable, and easier to verify",
  "Real Bahamian cases and statutes, not pattern guessing",
  "Trust matters in law. Grounded answers earn trust.",
]

const disclaimers = [
  "Not legal advice; talk to a lawyer for decisions that matter.",
  "Not a courtroom representative; you still need a lawyer for hearings.",
  "Limited to Bahamian law; does not provide reliable answers for other jurisdictions.",
  "Not perfect; AI can err, so double-check important points with official sources.",
]

export function Trust() {
  const [leftRef, leftVisible] = useAnimateIn<HTMLDivElement>()
  const [rightRef, rightVisible] = useAnimateIn<HTMLDivElement>()

  return (
    <section className="relative py-32 px-6 lg:px-8">
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-7xl">
        <div className="h-px bg-border" />
      </div>

      <div className="mx-auto max-w-7xl">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 lg:gap-24">
          {/* Why grounded AI matters */}
          <div
            ref={leftRef}
            className={`transition-all duration-1000 ${
              leftVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
            }`}
          >
            <p className="text-xs tracking-[0.2em] uppercase text-accent font-mono mb-4">
              Grounded AI
            </p>
            <h2 className="text-3xl md:text-4xl font-bold tracking-tight mb-6 text-balance">
              Why grounded AI matters
            </h2>
            <p className="text-muted-foreground leading-relaxed mb-8">
              Most legal AI tools guess from patterns, which can produce
              persuasive but incorrect results. LawBey uses retrieval first, then
              AI to explain the retrieved material.
            </p>

            <div className="flex flex-col gap-4">
              {trustPoints.map((point, i) => (
                <div
                  key={i}
                  className="flex items-start gap-3 text-sm"
                >
                  <CheckCircle2 className="h-4 w-4 text-accent mt-0.5 shrink-0" />
                  <span className="text-foreground/80">{point}</span>
                </div>
              ))}
            </div>
          </div>

          {/* What LawBey is not */}
          <div
            ref={rightRef}
            className={`transition-all duration-1000 delay-200 ${
              rightVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
            }`}
          >
            <p className="text-xs tracking-[0.2em] uppercase text-muted-foreground font-mono mb-4">
              Transparency
            </p>
            <h2 className="text-3xl md:text-4xl font-bold tracking-tight mb-6 text-balance">
              What LawBey is not
            </h2>
            <p className="text-muted-foreground leading-relaxed mb-8">
              We believe in clarity about what this tool can and cannot do. Here
              is what you should know.
            </p>

            <div className="flex flex-col gap-4">
              {disclaimers.map((item, i) => (
                <div
                  key={i}
                  className="flex items-start gap-3 text-sm"
                >
                  <AlertTriangle className="h-4 w-4 text-muted-foreground mt-0.5 shrink-0" />
                  <span className="text-foreground/70">{item}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
