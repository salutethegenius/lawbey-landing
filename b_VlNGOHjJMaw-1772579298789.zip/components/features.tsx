"use client"

import { useAnimateIn } from "@/hooks/use-animate-in"
import {
  Shield,
  Scale,
  Building2,
  Home,
  Users,
  Briefcase,
} from "lucide-react"

const features = [
  {
    icon: Shield,
    title: "Your rights",
    description:
      "Consumer protections, criminal procedure, and civil claims explained clearly.",
  },
  {
    icon: Scale,
    title: "Court process",
    description:
      "What to expect if a case goes to court, step by step.",
  },
  {
    icon: Building2,
    title: "Starting a business",
    description:
      "Registration, licensing basics, and common compliance steps.",
  },
  {
    icon: Home,
    title: "Property and leases",
    description:
      "Buying, selling, renting, and landlord obligations in The Bahamas.",
  },
  {
    icon: Users,
    title: "Family law",
    description:
      "Marriage, separation, and child custody basics under Bahamian law.",
  },
  {
    icon: Briefcase,
    title: "Work questions",
    description:
      "Employment rights, termination, contracts, NIB and labor basics.",
  },
]

export function Features() {
  const [headerRef, headerVisible] = useAnimateIn<HTMLDivElement>()

  return (
    <section id="features" className="relative py-32 px-6 lg:px-8">
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-7xl">
        <div className="h-px bg-border" />
      </div>

      <div className="mx-auto max-w-7xl">
        <div
          ref={headerRef}
          className={`mb-20 text-center transition-all duration-1000 ${
            headerVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
          }`}
        >
          <p className="text-xs tracking-[0.2em] uppercase text-accent font-mono mb-4">
            Capabilities
          </p>
          <h2 className="text-3xl md:text-5xl font-bold tracking-tight text-balance">
            What LawBey can help you with
          </h2>
          <p className="mt-4 text-muted-foreground text-lg max-w-2xl mx-auto leading-relaxed">
            If it is about Bahamian law, LawBey can usually point you in the
            right direction.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, i) => (
            <FeatureCard key={feature.title} feature={feature} index={i} />
          ))}
        </div>
      </div>
    </section>
  )
}

function FeatureCard({
  feature,
  index,
}: {
  feature: (typeof features)[number]
  index: number
}) {
  const [ref, isVisible] = useAnimateIn<HTMLDivElement>()
  const Icon = feature.icon

  return (
    <div
      ref={ref}
      className={`group relative p-8 rounded-lg border border-border bg-card/30 hover:bg-card/60 transition-all duration-500 ${
        isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"
      }`}
      style={{ transitionDelay: `${index * 100}ms` }}
    >
      <div className="mb-5 h-10 w-10 rounded-md bg-secondary flex items-center justify-center transition-all duration-300 group-hover:bg-accent/10 group-hover:scale-105">
        <Icon className="h-5 w-5 text-muted-foreground transition-colors duration-300 group-hover:text-accent" />
      </div>
      <h3 className="text-base font-semibold mb-2 tracking-tight">
        {feature.title}
      </h3>
      <p className="text-sm text-muted-foreground leading-relaxed">
        {feature.description}
      </p>
    </div>
  )
}
