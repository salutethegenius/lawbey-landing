"use client"

import { useAnimateIn } from "@/hooks/use-animate-in"
import Link from "next/link"
import { ArrowUpRight } from "lucide-react"

export function CTA() {
  const [ref, isVisible] = useAnimateIn<HTMLDivElement>()

  return (
    <section className="relative py-32 px-6 lg:px-8">
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-7xl">
        <div className="h-px bg-border" />
      </div>

      <div className="mx-auto max-w-4xl text-center">
        <div
          ref={ref}
          className={`transition-all duration-1000 ${
            isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
          }`}
        >
          <h2 className="text-3xl md:text-5xl font-bold tracking-tight mb-6 text-balance">
            Get started today
          </h2>
          <p className="text-muted-foreground text-lg max-w-xl mx-auto leading-relaxed mb-10">
            No signup required for the free layer. No credit card needed. For
            firms and professionals, LawBey Pro brings faster research and
            document workflows.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link
              href="https://beta.lawbey.com"
              className="group flex items-center gap-2 px-8 py-3.5 bg-foreground text-background font-medium rounded-md hover:bg-foreground/90 transition-all duration-300 text-sm"
            >
              Start Chatting
              <ArrowUpRight className="h-4 w-4 transition-transform duration-300 group-hover:-translate-y-0.5 group-hover:translate-x-0.5" />
            </Link>
            <Link
              href="#pro"
              className="flex items-center gap-2 px-8 py-3.5 border border-border text-foreground font-medium rounded-md hover:bg-secondary/50 transition-all duration-300 text-sm"
            >
              See Pro Features
            </Link>
          </div>
        </div>
      </div>
    </section>
  )
}
