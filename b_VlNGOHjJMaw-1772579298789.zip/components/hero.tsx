"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { ArrowUpRight } from "lucide-react"

export function Hero() {
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Subtle grid background */}
      <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.02)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.02)_1px,transparent_1px)] bg-[size:64px_64px]" />

      {/* Radial glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-accent/5 rounded-full blur-[120px]" />

      <div className="relative z-10 mx-auto max-w-5xl px-6 text-center">
        {/* Badge */}
        <div
          className={`inline-flex items-center gap-2 px-4 py-1.5 mb-8 rounded-full border border-border bg-secondary/50 transition-all duration-1000 ${
            mounted
              ? "opacity-100 translate-y-0"
              : "opacity-0 translate-y-4"
          }`}
        >
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-accent opacity-75" />
            <span className="relative inline-flex rounded-full h-2 w-2 bg-accent" />
          </span>
          <span className="text-xs font-medium text-muted-foreground tracking-wide uppercase">
            Now in Beta
          </span>
        </div>

        {/* Heading */}
        <h1
          className={`text-4xl sm:text-5xl md:text-7xl font-bold tracking-tight leading-[1.1] text-balance transition-all duration-1000 delay-200 ${
            mounted
              ? "opacity-100 translate-y-0"
              : "opacity-0 translate-y-6"
          }`}
        >
          Simple, reliable answers
          <br />
          <span className="text-muted-foreground">about law in The Bahamas</span>
        </h1>

        {/* Subtitle */}
        <p
          className={`mt-6 text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto leading-relaxed text-pretty transition-all duration-1000 delay-400 ${
            mounted
              ? "opacity-100 translate-y-0"
              : "opacity-0 translate-y-6"
          }`}
        >
          Get clear explanations of Bahamian law in plain English. Ask questions in
          everyday language, and LawBey retrieves real cases and legal texts, then
          explains them so you can act with confidence.
        </p>

        {/* CTAs */}
        <div
          className={`mt-10 flex flex-col sm:flex-row items-center justify-center gap-4 transition-all duration-1000 delay-[600ms] ${
            mounted
              ? "opacity-100 translate-y-0"
              : "opacity-0 translate-y-6"
          }`}
        >
          <Link
            href="https://beta.lawbey.com"
            className="group flex items-center gap-2 px-8 py-3.5 bg-foreground text-background font-medium rounded-md hover:bg-foreground/90 transition-all duration-300 text-sm"
          >
            Ask LawBey a Question, Free
            <ArrowUpRight className="h-4 w-4 transition-transform duration-300 group-hover:-translate-y-0.5 group-hover:translate-x-0.5" />
          </Link>
          <Link
            href="#how-it-works"
            className="group flex items-center gap-2 px-8 py-3.5 border border-border text-foreground font-medium rounded-md hover:bg-secondary/50 transition-all duration-300 text-sm"
          >
            See How It Works
          </Link>
        </div>

        {/* Scroll indicator */}
        <div
          className={`mt-20 transition-all duration-1000 delay-[800ms] ${
            mounted ? "opacity-100" : "opacity-0"
          }`}
        >
          <div className="flex flex-col items-center gap-2 text-muted-foreground">
            <span className="text-xs tracking-widest uppercase">Scroll</span>
            <div className="w-px h-8 bg-border relative overflow-hidden">
              <div className="w-px h-4 bg-accent animate-[slideDown_2s_ease-in-out_infinite]" />
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
