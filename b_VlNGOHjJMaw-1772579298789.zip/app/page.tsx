import { Navbar } from "@/components/navbar"
import { Hero } from "@/components/hero"
import { HowItWorks } from "@/components/how-it-works"
import { Features } from "@/components/features"
import { Trust } from "@/components/trust"
import { WhoUses } from "@/components/who-uses"
import { ProSection } from "@/components/pro-section"
import { Mission } from "@/components/mission"
import { CTA } from "@/components/cta"
import { Footer } from "@/components/footer"

export default function Page() {
  return (
    <main className="min-h-screen bg-background">
      <Navbar />
      <Hero />
      <HowItWorks />
      <Features />
      <Trust />
      <WhoUses />
      <ProSection />
      <Mission />
      <CTA />
      <Footer />
    </main>
  )
}
